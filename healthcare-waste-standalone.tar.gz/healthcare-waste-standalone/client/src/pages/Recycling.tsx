import { motion } from "framer-motion";
import { Recycle, Clock, MapPin, CheckCircle2, Loader2, AlertTriangle } from "lucide-react";
import { useGetUpcomingRecycling, useMarkAsRecycled } from "@/api/hooks";
import { useQueryClient } from "@tanstack/react-query";
import { format, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

export default function Recycling() {
  const queryClient = useQueryClient();
  const { data: items = [], isLoading } = useGetUpcomingRecycling();
  const { mutate: markRecycled, isPending } = useMarkAsRecycled({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
        toast.success("Item marked as recycled!");
      },
    },
  });

  const now = new Date();
  const overdue    = items.filter((i) => new Date(i.recyclingDate) < now);
  const upcoming   = items.filter((i) => new Date(i.recyclingDate) >= now);

  function renderCard(item: typeof items[0]) {
    const isOverdue = new Date(item.recyclingDate) < now;
    return (
      <motion.div
        key={item.id}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className={`bg-white rounded-2xl border shadow-md p-5 flex flex-col gap-4 hover:shadow-lg transition-shadow ${isOverdue ? "border-red-200 shadow-red-100/40" : "border-slate-100 shadow-slate-200/60"}`}
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={`w-2.5 h-2.5 rounded-full ${isOverdue ? "bg-red-500 animate-pulse" : "bg-amber-400"}`} />
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                {isOverdue ? "OVERDUE" : "DUE SOON"}
              </span>
            </div>
            <h3 className="font-bold text-slate-900 capitalize text-base">{item.type} Waste</h3>
            <p className="text-xs text-slate-500 mt-0.5 leading-snug">{item.description}</p>
          </div>
          <span className="text-xs font-mono text-slate-400">#{item.id}</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-50 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs mb-1">
              <MapPin className="w-3.5 h-3.5" />
              Location
            </div>
            <p className="text-sm font-semibold text-slate-800 truncate">{item.location}</p>
          </div>
          <div className="bg-slate-50 rounded-xl p-3">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs mb-1">
              <Clock className="w-3.5 h-3.5" />
              Due
            </div>
            <p className={`text-sm font-semibold truncate ${isOverdue ? "text-red-600" : "text-amber-600"}`}>
              {formatDistanceToNow(new Date(item.recyclingDate), { addSuffix: true })}
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-slate-500">
            {item.quantity} {item.unit} · {item.aiClassification}
          </p>
          <button
            onClick={() => markRecycled({ id: item.id })}
            disabled={isPending}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm shadow-emerald-600/20 transition-all hover:scale-105 active:scale-95 disabled:opacity-60"
          >
            {isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle2 className="w-4 h-4" />
            )}
            Mark Recycled
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Recycling Scheduler</h1>
        <p className="text-slate-500 mt-1">All pending items due for recycling within the next 48 hours.</p>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-white rounded-2xl border border-slate-100 shadow-md p-5 animate-pulse">
              <div className="h-5 bg-slate-100 rounded w-2/3 mb-3" />
              <div className="h-4 bg-slate-100 rounded w-full mb-2" />
              <div className="h-4 bg-slate-100 rounded w-1/2" />
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-md p-16 text-center">
          <Recycle className="w-14 h-14 text-emerald-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-slate-800 mb-2">All caught up!</h3>
          <p className="text-slate-500">No items are due for recycling in the next 48 hours.</p>
        </div>
      ) : (
        <>
          {overdue.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-4">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <h2 className="text-lg font-bold text-red-700">Overdue ({overdue.length})</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {overdue.map(renderCard)}
              </div>
            </section>
          )}
          {upcoming.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-amber-500" />
                <h2 className="text-lg font-bold text-amber-700">Upcoming ({upcoming.length})</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {upcoming.map(renderCard)}
              </div>
            </section>
          )}
        </>
      )}
    </motion.div>
  );
}
