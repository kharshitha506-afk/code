import { motion } from "framer-motion";
import { Leaf, Wind, Recycle, BarChart3, TrendingUp } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";
import { useGetSustainabilityMetrics } from "@/api/hooks";

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444", "#64748b", "#ec4899"];

function MetricCard({ icon: Icon, title, value, unit, gradient, subtitle }: {
  icon: React.ElementType; title: string; value: string | number; unit: string;
  gradient: string; subtitle?: string;
}) {
  return (
    <div className={`rounded-2xl p-6 text-white relative overflow-hidden shadow-xl ${gradient}`}>
      <div className="absolute -right-4 -bottom-4 opacity-20">
        <Icon className="w-24 h-24" />
      </div>
      <Icon className="w-8 h-8 mb-4 relative z-10" />
      <p className="text-4xl font-bold relative z-10 tracking-tight">{value}</p>
      <p className="text-sm opacity-90 font-medium relative z-10">{unit}</p>
      <p className="text-lg font-semibold mt-2 relative z-10">{title}</p>
      {subtitle && <p className="text-xs opacity-75 mt-0.5 relative z-10">{subtitle}</p>}
    </div>
  );
}

export default function Sustainability() {
  const { data: metrics, isLoading } = useGetSustainabilityMetrics();

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-display font-bold text-slate-900">Sustainability Metrics</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-40 bg-slate-200 rounded-2xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (!metrics) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Sustainability Metrics</h1>
        <p className="text-slate-500 mt-1">Track your facility's environmental impact and recycling performance.</p>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <MetricCard
          icon={Leaf}
          title="CO₂ Saved"
          value={metrics.co2Saved}
          unit="kilograms avoided"
          gradient="bg-gradient-to-br from-emerald-600 to-teal-500"
          subtitle="Through proper recycling"
        />
        <MetricCard
          icon={Recycle}
          title="Recycling Rate"
          value={`${metrics.recyclingRate}%`}
          unit="of all waste items"
          gradient="bg-gradient-to-br from-blue-600 to-indigo-500"
          subtitle={`${metrics.totalRecycled} items recycled`}
        />
        <MetricCard
          icon={Wind}
          title="Plastic Recycled"
          value={metrics.plasticRecycled}
          unit="kilograms diverted"
          gradient="bg-gradient-to-br from-violet-600 to-purple-500"
          subtitle="From landfill or incineration"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Weekly trend */}
        <div className="xl:col-span-2 bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 p-6">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-800">Weekly Waste vs Recycling Trend</h3>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={metrics.weeklyTrend} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
              <defs>
                <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorRecycled" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#10b981" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="week" tick={{ fontSize: 12, fill: "#94a3b8" }} />
              <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} />
              <Tooltip
                contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0", boxShadow: "0 4px 24px #0000001a" }}
              />
              <Legend wrapperStyle={{ fontSize: "12px" }} />
              <Area type="monotone" dataKey="total"   name="Total"   stroke="#3b82f6" fill="url(#colorTotal)"   strokeWidth={2.5} dot={{ r: 4, fill: "#3b82f6" }} />
              <Area type="monotone" dataKey="recycled" name="Recycled" stroke="#10b981" fill="url(#colorRecycled)" strokeWidth={2.5} dot={{ r: 4, fill: "#10b981" }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-800">Waste by Type</h3>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <PieChart>
              <Pie
                data={metrics.wasteByType.filter((d) => d.count > 0)}
                cx="50%" cy="50%"
                innerRadius={40} outerRadius={65}
                paddingAngle={3}
                dataKey="count"
                nameKey="type"
              >
                {metrics.wasteByType.map((_, idx) => (
                  <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0" }}
                formatter={(val, name) => [val, String(name).charAt(0).toUpperCase() + String(name).slice(1)]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-2 space-y-1.5">
            {metrics.wasteByType.filter((d) => d.count > 0).slice(0, 5).map((d, idx) => (
              <div key={d.type} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                  <span className="text-slate-600 capitalize">{d.type}</span>
                </div>
                <span className="font-semibold text-slate-800">{d.count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bar chart breakdown */}
      <div className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 p-6">
        <h3 className="font-bold text-slate-800 mb-6">Recycling Breakdown by Waste Type</h3>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={metrics.wasteByType} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis dataKey="type" tick={{ fontSize: 12, fill: "#94a3b8" }} />
            <YAxis tick={{ fontSize: 12, fill: "#94a3b8" }} />
            <Tooltip
              contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0" }}
            />
            <Legend wrapperStyle={{ fontSize: "12px" }} />
            <Bar dataKey="count"    name="Total"    fill="#3b82f6" radius={[6, 6, 0, 0]} />
            <Bar dataKey="recycled" name="Recycled" fill="#10b981" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
