import { motion } from "framer-motion";
import { Trash2, CheckCircle2, Recycle, Clock, TrendingUp, AlertTriangle, Leaf, Zap } from "lucide-react";
import { useGetSustainabilityMetrics, useListWasteItems } from "@/api/hooks";
import { formatNumber } from "@/lib/utils";
import { format } from "date-fns";
import { getStatusColor } from "@/lib/utils";

const cardVariants = {
  hidden:  { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.07, duration: 0.4, ease: "easeOut" },
  }),
};

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ElementType;
  gradient: string;
  iconColor: string;
  subtitle?: string;
  trend?: string;
  index: number;
}

function StatCard({ title, value, icon: Icon, gradient, iconColor, subtitle, trend, index }: StatCardProps) {
  return (
    <motion.div
      custom={index}
      initial="hidden"
      animate="visible"
      variants={cardVariants}
      className="bg-white rounded-2xl p-6 shadow-md shadow-slate-200/60 border border-slate-100 relative overflow-hidden group hover:shadow-lg hover:shadow-slate-200/80 transition-shadow"
    >
      <div className={`absolute -right-6 -top-6 w-28 h-28 rounded-full opacity-10 group-hover:opacity-15 transition-opacity ${gradient}`} />
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 rounded-xl ${gradient} bg-opacity-15`}>
          <Icon className={`w-6 h-6 ${iconColor}`} />
        </div>
        {trend && (
          <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />{trend}
          </span>
        )}
      </div>
      <p className="text-3xl font-bold text-slate-900 mb-1 tracking-tight">{value}</p>
      <p className="text-sm font-semibold text-slate-700">{title}</p>
      {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
    </motion.div>
  );
}

export default function Dashboard() {
  const { data: metrics, isLoading: loadingMetrics } = useGetSustainabilityMetrics();
  const { data: items = [], isLoading: loadingItems } = useListWasteItems();

  const recentItems = [...items]
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 6);

  const pendingItems = items.filter((i) => i.status === "pending");
  const urgentItems  = pendingItems.filter(
    (i) => new Date(i.recyclingDate) <= new Date()
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        <StatCard
          index={0}
          title="Total Processed"
          value={loadingMetrics ? "—" : formatNumber(metrics?.totalProcessed ?? 0)}
          icon={Trash2}
          gradient="bg-blue-500"
          iconColor="text-blue-600"
          subtitle="All time waste items"
          trend="+12%"
        />
        <StatCard
          index={1}
          title="Recycled Items"
          value={loadingMetrics ? "—" : formatNumber(metrics?.totalRecycled ?? 0)}
          icon={Recycle}
          gradient="bg-emerald-500"
          iconColor="text-emerald-600"
          subtitle={`${metrics?.recyclingRate ?? 0}% recycling rate`}
          trend="+8%"
        />
        <StatCard
          index={2}
          title="Properly Disposed"
          value={loadingMetrics ? "—" : formatNumber(metrics?.totalDisposed ?? 0)}
          icon={CheckCircle2}
          gradient="bg-indigo-500"
          iconColor="text-indigo-600"
          subtitle="Non-recyclable waste"
        />
        <StatCard
          index={3}
          title="Pending Review"
          value={loadingMetrics ? "—" : formatNumber(metrics?.totalPending ?? 0)}
          icon={Clock}
          gradient="bg-amber-500"
          iconColor="text-amber-600"
          subtitle="Awaiting processing"
        />
      </div>

      {/* CO₂ + alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.32 }}
          className="lg:col-span-2 bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-900 rounded-2xl p-8 text-white relative overflow-hidden shadow-xl shadow-indigo-900/20"
        >
          <div className="absolute inset-0 opacity-[0.04] pointer-events-none">
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute rounded-full border border-white"
                style={{
                  width: `${(i + 1) * 120}px`,
                  height: `${(i + 1) * 120}px`,
                  right: "-50px", top: "-50px",
                  transform: `translate(${i * 20}%, ${i * 20}%)`,
                }}
              />
            ))}
          </div>
          <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center gap-6">
            <div className="p-4 bg-white/10 rounded-2xl backdrop-blur-sm">
              <Leaf className="w-10 h-10 text-emerald-300" />
            </div>
            <div>
              <p className="text-blue-200 text-sm font-semibold uppercase tracking-widest mb-1">Environmental Impact</p>
              <h2 className="text-5xl font-bold tracking-tight mb-1">
                {loadingMetrics ? "—" : `${metrics?.co2Saved ?? 0} kg`}
              </h2>
              <p className="text-blue-200 text-lg">CO₂ emissions saved through responsible recycling</p>
            </div>
            <div className="ml-auto text-right hidden sm:block">
              <p className="text-4xl font-bold text-emerald-300">
                {loadingMetrics ? "—" : `${metrics?.plasticRecycled ?? 0} kg`}
              </p>
              <p className="text-blue-300 text-sm mt-1">Plastic recycled</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.38 }}
          className="bg-white rounded-2xl p-6 shadow-md shadow-slate-200/60 border border-slate-100"
        >
          <div className="flex items-center gap-2 mb-5">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-800">Attention Required</h3>
          </div>
          {urgentItems.length === 0 && pendingItems.length === 0 ? (
            <div className="text-center py-6">
              <Zap className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-700">All caught up!</p>
              <p className="text-xs text-slate-500 mt-1">No pending or overdue items.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {urgentItems.length > 0 && (
                <div className="bg-red-50 border border-red-100 rounded-xl p-3">
                  <p className="text-sm font-bold text-red-700">{urgentItems.length} Overdue Items</p>
                  <p className="text-xs text-red-600 mt-0.5">Recycling date has passed — immediate action required</p>
                </div>
              )}
              {pendingItems.length > 0 && (
                <div className="bg-amber-50 border border-amber-100 rounded-xl p-3">
                  <p className="text-sm font-bold text-amber-700">{pendingItems.length} Pending Items</p>
                  <p className="text-xs text-amber-600 mt-0.5">Scheduled for recycling or disposal</p>
                </div>
              )}
            </div>
          )}
        </motion.div>
      </div>

      {/* Recent items table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.44 }}
        className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-lg">Recent Waste Items</h3>
          <span className="text-xs text-slate-500 font-medium">{items.length} total items</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 text-xs uppercase tracking-wider">
                <th className="p-4 border-b border-slate-100 font-semibold">ID</th>
                <th className="p-4 border-b border-slate-100 font-semibold">Type</th>
                <th className="p-4 border-b border-slate-100 font-semibold">Location</th>
                <th className="p-4 border-b border-slate-100 font-semibold">Amount</th>
                <th className="p-4 border-b border-slate-100 font-semibold">Date</th>
                <th className="p-4 border-b border-slate-100 font-semibold text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {loadingItems ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={6} className="p-4">
                      <div className="h-10 bg-slate-100 rounded w-full" />
                    </td>
                  </tr>
                ))
              ) : (
                recentItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 font-mono text-slate-500 text-xs font-medium">#{item.id}</td>
                    <td className="p-4">
                      <span className="capitalize font-semibold text-slate-800">{item.type}</span>
                      <p className="text-xs text-slate-500 mt-0.5 truncate max-w-[160px]">{item.description}</p>
                    </td>
                    <td className="p-4 text-slate-600">{item.location}</td>
                    <td className="p-4 font-medium text-slate-700">{item.quantity} {item.unit}</td>
                    <td className="p-4 text-slate-500 text-xs">
                      {format(new Date(item.timestamp), "MMM dd, yyyy")}
                    </td>
                    <td className="p-4 text-right">
                      <span className={`px-3 py-1.5 rounded-full text-xs font-bold border ${getStatusColor(item.status)}`}>
                        {item.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </motion.div>
    </motion.div>
  );
}
