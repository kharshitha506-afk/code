import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Filter, Calendar } from "lucide-react";
import { format } from "date-fns";
import { useListWasteItems } from "@/api/hooks";
import { getStatusColor } from "@/lib/utils";

export default function History() {
  const [searchTerm, setSearchTerm] = useState("");
  const { data: items = [], isLoading } = useListWasteItems();

  const historyItems = items
    .filter((item) => item.status !== "pending")
    .filter(
      (item) =>
        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.id.toString().includes(searchTerm)
    )
    .sort((a, b) => {
      const dateA = a.disposedAt || a.recycledAt || a.timestamp;
      const dateB = b.disposedAt || b.recycledAt || b.timestamp;
      return new Date(dateB).getTime() - new Date(dateA).getTime();
    });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Waste History</h1>
          <p className="text-slate-500 mt-1">Archive of all disposed and recycled items.</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search history…"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 transition-all"
            />
          </div>
          <button className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors">
            <Filter className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-slate-600 text-xs uppercase tracking-wider font-bold">
                <th className="p-4 border-b border-slate-100">ID</th>
                <th className="p-4 border-b border-slate-100">Type & Description</th>
                <th className="p-4 border-b border-slate-100">Amount</th>
                <th className="p-4 border-b border-slate-100">Resolution Date</th>
                <th className="p-4 border-b border-slate-100 text-right">Final Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {isLoading ? (
                [...Array(6)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={5} className="p-4">
                      <div className="h-10 bg-slate-100 rounded w-full" />
                    </td>
                  </tr>
                ))
              ) : historyItems.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-12 text-center text-slate-500">
                    <Calendar className="w-10 h-10 mx-auto text-slate-300 mb-3" />
                    <p className="text-base font-semibold text-slate-800">No history found</p>
                    <p className="mt-1 text-sm">
                      {searchTerm ? "Try adjusting your search terms." : "Completed items will appear here."}
                    </p>
                  </td>
                </tr>
              ) : (
                historyItems.map((item) => {
                  const resolvedDate = item.status === "recycled" ? item.recycledAt : item.disposedAt;
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="p-4 font-mono font-medium text-slate-500">#{item.id}</td>
                      <td className="p-4">
                        <div className="font-semibold text-slate-900 capitalize">{item.type}</div>
                        <div className="text-xs text-slate-500 mt-0.5 max-w-xs truncate">{item.description}</div>
                      </td>
                      <td className="p-4 font-medium text-slate-700">
                        {item.quantity} {item.unit}
                      </td>
                      <td className="p-4 text-slate-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0" />
                          {resolvedDate
                            ? format(new Date(resolvedDate), "MMM dd, yyyy")
                            : "Unknown"}
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        <span
                          className={`px-3 py-1.5 rounded-full text-xs font-bold inline-flex items-center justify-center min-w-[90px] border ${getStatusColor(item.status)}`}
                        >
                          {item.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        {!isLoading && historyItems.length > 0 && (
          <div className="px-4 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs text-slate-500">
            <span>{historyItems.length} items</span>
            <span>Sorted by most recent first</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}
