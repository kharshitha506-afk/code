import { motion } from "framer-motion";
import { FileDown, ShieldAlert, ShieldCheck, UserCircle } from "lucide-react";
import { format } from "date-fns";
import { useGetComplianceLogs, useExportComplianceReport } from "@/api/hooks";

export default function Compliance() {
  const { data: logs = [], isLoading } = useGetComplianceLogs();
  const { refetch: exportReport, isFetching: isExporting } = useExportComplianceReport({
    query: { enabled: false },
  });

  const handleExport = async () => {
    const { data } = await exportReport();
    if (data) {
      const blob = new Blob([data], { type: "text/csv" });
      const url  = window.URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href     = url;
      a.download = `compliance_report_${format(new Date(), "yyyy-MM-dd")}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Hero header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gradient-to-r from-slate-900 to-indigo-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl shadow-indigo-900/20 relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 pointer-events-none translate-x-1/4 -translate-y-1/4">
          <ShieldCheck className="w-64 h-64" />
        </div>
        <div className="relative z-10">
          <h1 className="text-3xl font-display font-bold tracking-tight">Audit & Compliance</h1>
          <p className="text-indigo-200 mt-1 max-w-xl">
            Immutable ledger of all waste actions. Ensure your facility meets all regulatory requirements.
          </p>
        </div>
        <button
          onClick={handleExport}
          disabled={isExporting}
          className="relative z-10 flex items-center gap-2 px-5 py-3 bg-white text-indigo-900 rounded-xl font-bold shadow-lg hover:bg-indigo-50 hover:scale-105 active:scale-95 transition-all disabled:opacity-70 flex-shrink-0"
        >
          <FileDown className="w-5 h-5" />
          {isExporting ? "Generating…" : "Export CSV"}
        </button>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Total Logs",    value: logs.length,                              color: "text-slate-800" },
          { label: "Compliant",     value: logs.filter((l) => l.isCompliant).length,  color: "text-emerald-600" },
          { label: "Flagged",       value: logs.filter((l) => !l.isCompliant).length, color: "text-red-600"     },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 text-center">
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs font-semibold text-slate-500 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h2 className="font-bold text-slate-800">Audit Log</h2>
          <span className="text-xs text-slate-500">{logs.length} entries</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 text-slate-500 text-xs uppercase tracking-wider font-semibold">
                <th className="p-4 border-b border-slate-100">Time</th>
                <th className="p-4 border-b border-slate-100">Action</th>
                <th className="p-4 border-b border-slate-100">Item Detail</th>
                <th className="p-4 border-b border-slate-100">Operator</th>
                <th className="p-4 border-b border-slate-100">Compliance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {isLoading ? (
                [...Array(6)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={5} className="p-4">
                      <div className="h-10 bg-slate-100 rounded w-full" />
                    </td>
                  </tr>
                ))
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-500">
                    No audit logs found.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 text-slate-600 font-mono text-xs whitespace-nowrap">
                      {format(new Date(log.timestamp), "yyyy-MM-dd HH:mm:ss")}
                    </td>
                    <td className="p-4">
                      <span
                        className={`px-2.5 py-1 rounded text-xs font-bold uppercase tracking-wider ${
                          log.action === "upload"   ? "bg-blue-100 text-blue-700"
                        : log.action === "disposal" ? "bg-amber-100 text-amber-700"
                        :                            "bg-emerald-100 text-emerald-700"
                        }`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="font-medium text-slate-900">
                        Item #{log.wasteItemId} ({log.wasteType})
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 truncate max-w-[200px]">
                        {log.description}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2 text-slate-700 font-medium">
                        <UserCircle className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        {log.performedBy}
                      </div>
                    </td>
                    <td className="p-4">
                      {log.isCompliant ? (
                        <div className="flex items-center gap-1.5 text-emerald-600 font-semibold text-xs">
                          <ShieldCheck className="w-4 h-4" />
                          VERIFIED
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-red-600 font-semibold text-xs group relative cursor-help">
                          <ShieldAlert className="w-4 h-4" />
                          FLAGGED
                          {log.notes && (
                            <div className="absolute bottom-full mb-2 left-0 hidden group-hover:block w-48 bg-slate-900 text-white text-xs p-2 rounded-lg shadow-xl z-10">
                              {log.notes}
                            </div>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
