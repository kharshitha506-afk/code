import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { UploadCloud, Bot, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { useCreateWasteItem } from "@/api/hooks";
import { toast } from "sonner";
import type { WasteItem } from "@/types";

const schema = z.object({
  type: z.enum(["sharps", "infectious", "pharmaceutical", "chemical", "radioactive", "general", "pathological"]),
  description: z.string().min(5, "Description must be at least 5 characters"),
  location:    z.string().min(2, "Please enter a location"),
  quantity:    z.coerce.number().positive("Must be greater than 0"),
  unit:        z.string().min(1, "Please select a unit"),
});

type FormData = z.infer<typeof schema>;

const WASTE_TYPES = [
  { value: "sharps",        label: "Sharps (needles, scalpels)",      color: "bg-red-100 text-red-800"     },
  { value: "infectious",    label: "Infectious / Biological",          color: "bg-orange-100 text-orange-800"},
  { value: "pharmaceutical",label: "Pharmaceutical / Chemical Drugs",  color: "bg-purple-100 text-purple-800"},
  { value: "chemical",      label: "Chemical Waste",                   color: "bg-yellow-100 text-yellow-800"},
  { value: "radioactive",   label: "Radioactive Waste",                color: "bg-pink-100 text-pink-800"   },
  { value: "general",       label: "General Medical Waste",            color: "bg-slate-100 text-slate-800" },
  { value: "pathological",  label: "Pathological / Anatomical",        color: "bg-rose-100 text-rose-800"   },
];

export default function Upload() {
  const [result, setResult] = useState<WasteItem | null>(null);

  const { mutate: createWaste, isPending } = useCreateWasteItem({
    mutation: {
      onSuccess: (data) => {
        setResult(data);
        reset();
        toast.success("Waste item uploaded and classified successfully!");
      },
    },
  });

  const { register, handleSubmit, formState: { errors }, reset, watch } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { unit: "kg" },
  });

  const selectedType = watch("type");

  const onSubmit = (data: FormData) => {
    createWaste({ data });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6 max-w-4xl"
    >
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Upload Waste</h1>
        <p className="text-slate-500 mt-1">Log a new biomedical waste item. AI will auto-classify it.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Form */}
        <div className="lg:col-span-3 bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 p-6">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            {/* Waste Type */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Waste Type</label>
              <select
                {...register("type")}
                className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 text-slate-800"
              >
                <option value="">Select waste type…</option>
                {WASTE_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
              {errors.type && <p className="text-red-500 text-xs mt-1">{errors.type.message}</p>}
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Description</label>
              <textarea
                {...register("description")}
                rows={3}
                placeholder="Describe the waste item in detail…"
                className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 text-slate-800 placeholder:text-slate-400 resize-none"
              />
              {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description.message}</p>}
            </div>

            {/* Location */}
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Location / Ward</label>
              <input
                {...register("location")}
                type="text"
                placeholder="e.g. ICU Unit, Surgical Suite 3…"
                className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 text-slate-800 placeholder:text-slate-400"
              />
              {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location.message}</p>}
            </div>

            {/* Quantity & Unit */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Quantity</label>
                <input
                  {...register("quantity")}
                  type="number"
                  step="0.1"
                  placeholder="0.0"
                  className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 text-slate-800"
                />
                {errors.quantity && <p className="text-red-500 text-xs mt-1">{errors.quantity.message}</p>}
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Unit</label>
                <select
                  {...register("unit")}
                  className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 text-slate-800"
                >
                  <option value="kg">kg</option>
                  <option value="liters">liters</option>
                  <option value="units">units</option>
                  <option value="bags">bags</option>
                  <option value="containers">containers</option>
                  <option value="vials">vials</option>
                  <option value="specimens">specimens</option>
                  <option value="ml">ml</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={isPending}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl transition-all shadow-md shadow-blue-600/20 hover:shadow-lg hover:scale-[1.01] active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isPending ? (
                <><Loader2 className="w-5 h-5 animate-spin" /> AI Classifying…</>
              ) : (
                <><UploadCloud className="w-5 h-5" /> Upload & Classify</>
              )}
            </button>
          </form>
        </div>

        {/* Right panel */}
        <div className="lg:col-span-2 space-y-4">
          {/* AI Result */}
          {result ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 p-6"
            >
              <div className="flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <h3 className="font-bold text-slate-800">AI Classification Result</h3>
              </div>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">Classification</p>
                  <p className="text-sm font-semibold text-slate-900 mt-1">{result.aiClassification}</p>
                </div>
                <div className="flex items-center justify-between bg-emerald-50 rounded-xl p-3">
                  <span className="text-sm font-semibold text-slate-700">AI Confidence</span>
                  <span className="text-2xl font-bold text-emerald-600">
                    {Math.round(result.aiConfidence * 100)}%
                  </span>
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">Recycling Date</p>
                  <p className="text-sm font-semibold text-blue-600 mt-1">
                    {new Date(result.recyclingDate).toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 font-medium uppercase tracking-wide">Item ID</p>
                  <p className="text-sm font-mono font-bold text-slate-900 mt-1">#{result.id}</p>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center text-center min-h-[200px]">
              <Bot className="w-12 h-12 text-slate-300 mb-3" />
              <p className="text-sm font-semibold text-slate-600">AI Waiting…</p>
              <p className="text-xs text-slate-400 mt-1">Submit the form to see the classification result.</p>
            </div>
          )}

          {/* Waste type legend */}
          <div className="bg-white rounded-2xl shadow-md shadow-slate-200/60 border border-slate-100 p-5">
            <h3 className="font-bold text-slate-800 mb-3 text-sm">Waste Categories</h3>
            <div className="space-y-2">
              {WASTE_TYPES.map((t) => (
                <div
                  key={t.value}
                  className={`text-xs font-medium px-3 py-2 rounded-lg transition-all ${t.color} ${selectedType === t.value ? "ring-2 ring-offset-1 ring-blue-500" : ""}`}
                >
                  {t.label}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
