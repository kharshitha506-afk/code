export type WasteType =
  | "sharps"
  | "infectious"
  | "pharmaceutical"
  | "chemical"
  | "radioactive"
  | "general"
  | "pathological";

export type WasteStatus = "pending" | "disposed" | "recycled";
export type ComplianceAction = "upload" | "disposal" | "recycling";
export type NotificationPriority = "low" | "medium" | "high" | "critical";
export type NotificationType = "recycling_due" | "pending_waste" | "compliance_alert" | "system";

export interface WasteItem {
  id: number;
  type: WasteType;
  status: WasteStatus;
  description: string;
  location: string;
  quantity: number;
  unit: string;
  aiClassification: string;
  aiConfidence: number;
  timestamp: string;
  recyclingDate: string;
  isRecycled: boolean;
  disposedAt: string | null;
  recycledAt: string | null;
}

export interface CreateWasteItemRequest {
  type: WasteType;
  description: string;
  location: string;
  quantity: number;
  unit: string;
}

export interface SustainabilityMetrics {
  totalProcessed: number;
  totalRecycled: number;
  totalDisposed: number;
  totalPending: number;
  recyclingRate: number;
  co2Saved: number;
  plasticRecycled: number;
  wasteByType: { type: string; count: number; recycled: number }[];
  weeklyTrend: { week: string; total: number; recycled: number }[];
}

export interface ComplianceLog {
  id: number;
  action: ComplianceAction;
  wasteItemId: number;
  wasteType: string;
  description: string;
  performedBy: string;
  timestamp: string;
  isCompliant: boolean;
  notes: string | null;
}

export interface Notification {
  id: number;
  type: NotificationType;
  title: string;
  message: string;
  wasteItemId: number | null;
  isRead: boolean;
  priority: NotificationPriority;
  timestamp: string;
}
