import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type {
  WasteItem,
  CreateWasteItemRequest,
  SustainabilityMetrics,
  ComplianceLog,
  Notification,
} from "@/types";

const BASE = "/api";

async function apiFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(BASE + url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? "Request failed");
  }
  return res.json() as Promise<T>;
}

// ─── Waste ────────────────────────────────────────────────────────────────────

export function useListWasteItems(params?: { status?: string; type?: string }) {
  const qs = new URLSearchParams();
  if (params?.status) qs.set("status", params.status);
  if (params?.type)   qs.set("type", params.type);
  const query = qs.toString() ? `?${qs}` : "";

  return useQuery<WasteItem[]>({
    queryKey: ["/api/waste", params],
    queryFn: () => apiFetch<WasteItem[]>(`/waste${query}`),
  });
}

export function useCreateWasteItem(options?: {
  mutation?: { onSuccess?: (data: WasteItem) => void };
}) {
  const queryClient = useQueryClient();
  return useMutation<WasteItem, Error, { data: CreateWasteItemRequest }>({
    mutationFn: ({ data }) =>
      apiFetch<WasteItem>("/waste", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/waste"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sustainability"] });
      options?.mutation?.onSuccess?.(data);
    },
  });
}

export function useGetUpcomingRecycling() {
  return useQuery<WasteItem[]>({
    queryKey: ["/api/waste/recycling/upcoming"],
    queryFn: () => apiFetch<WasteItem[]>("/waste/recycling/upcoming"),
  });
}

export function useMarkAsRecycled(options?: {
  mutation?: { onSuccess?: () => void };
}) {
  const queryClient = useQueryClient();
  return useMutation<WasteItem, Error, { id: number }>({
    mutationFn: ({ id }) =>
      apiFetch<WasteItem>(`/waste/${id}/recycle`, { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/waste"] });
      queryClient.invalidateQueries({ queryKey: ["/api/waste/recycling/upcoming"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sustainability"] });
      options?.mutation?.onSuccess?.();
    },
  });
}

export function useMarkAsDisposed(options?: {
  mutation?: { onSuccess?: () => void };
}) {
  const queryClient = useQueryClient();
  return useMutation<WasteItem, Error, { id: number }>({
    mutationFn: ({ id }) =>
      apiFetch<WasteItem>(`/waste/${id}/dispose`, { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/waste"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sustainability"] });
      options?.mutation?.onSuccess?.();
    },
  });
}

// ─── Sustainability ───────────────────────────────────────────────────────────

export function useGetSustainabilityMetrics() {
  return useQuery<SustainabilityMetrics>({
    queryKey: ["/api/sustainability"],
    queryFn: () => apiFetch<SustainabilityMetrics>("/sustainability"),
  });
}

// ─── Compliance ───────────────────────────────────────────────────────────────

export function useGetComplianceLogs(params?: { action?: string }) {
  return useQuery<ComplianceLog[]>({
    queryKey: ["/api/compliance/logs", params],
    queryFn: () => {
      const qs = params?.action ? `?action=${params.action}` : "";
      return apiFetch<ComplianceLog[]>(`/compliance/logs${qs}`);
    },
  });
}

export function useExportComplianceReport(options?: { query?: { enabled?: boolean } }) {
  return useQuery<string>({
    queryKey: ["/api/compliance/export"],
    queryFn: async () => {
      const res = await fetch(BASE + "/compliance/export");
      if (!res.ok) throw new Error("Export failed");
      return res.text();
    },
    enabled: options?.query?.enabled ?? true,
  });
}

// ─── Notifications ────────────────────────────────────────────────────────────

export function useGetNotifications() {
  return useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    queryFn: () => apiFetch<Notification[]>("/notifications"),
    refetchInterval: 30000, // Auto-refresh every 30 seconds
  });
}

export function useMarkNotificationRead(options?: {
  mutation?: { onSuccess?: () => void };
}) {
  const queryClient = useQueryClient();
  return useMutation<Notification, Error, { id: number }>({
    mutationFn: ({ id }) =>
      apiFetch<Notification>(`/notifications/${id}/read`, { method: "POST" }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      options?.mutation?.onSuccess?.();
    },
  });
}
