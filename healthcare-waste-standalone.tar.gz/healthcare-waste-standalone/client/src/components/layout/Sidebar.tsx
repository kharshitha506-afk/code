import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, UploadCloud, Recycle,
  Leaf, History, ShieldCheck, Activity,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/",              label: "Dashboard",    icon: LayoutDashboard },
  { href: "/upload",        label: "Upload Waste", icon: UploadCloud     },
  { href: "/recycling",     label: "Recycling",    icon: Recycle         },
  { href: "/sustainability",label: "Sustainability",icon: Leaf            },
  { href: "/history",       label: "History",      icon: History         },
  { href: "/compliance",    label: "Compliance",   icon: ShieldCheck     },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="fixed inset-y-0 left-0 w-72 bg-white border-r border-slate-200 shadow-sm z-30 hidden lg:flex flex-col">
      {/* Logo */}
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
          <Activity className="w-6 h-6" />
        </div>
        <div>
          <h1 className="font-bold text-xl text-slate-900 leading-none tracking-tight">EcoMed</h1>
          <p className="text-xs text-slate-500 font-medium tracking-wide">Waste Management</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 px-3">
          Main Menu
        </p>
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = location === href;
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 font-medium group",
                active
                  ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              )}
            >
              <Icon
                className={cn(
                  "w-5 h-5 transition-transform duration-200 group-hover:scale-110",
                  active ? "text-white" : "text-slate-400 group-hover:text-blue-600"
                )}
              />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* AI Status card */}
      <div className="p-4 mt-auto">
        <div className="bg-blue-50 rounded-2xl p-5 border border-blue-100">
          <h4 className="font-bold text-slate-900 text-sm mb-1">AI System Active</h4>
          <p className="text-xs text-slate-600 mb-3 leading-relaxed">
            Automatic classification is monitoring all uploads.
          </p>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 bg-white rounded-lg py-1.5 px-3 shadow-sm w-fit">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            System Healthy
          </div>
        </div>
      </div>
    </aside>
  );
}
