import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";

export function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen flex" style={{ backgroundColor: "hsl(220 20% 97%)" }}>
      <Sidebar />
      <div className="flex-1 lg:ml-72 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-x-hidden relative">
          <div
            className="absolute top-0 right-0 w-96 h-96 rounded-full blur-3xl -z-10 pointer-events-none"
            style={{ backgroundColor: "hsl(221 83% 53% / 0.04)" }}
          />
          <div
            className="absolute top-40 left-0 w-72 h-72 rounded-full blur-3xl -z-10 pointer-events-none"
            style={{ backgroundColor: "hsl(199 89% 48% / 0.04)" }}
          />
          <div className="max-w-7xl mx-auto w-full">{children}</div>
        </main>
      </div>
    </div>
  );
}
