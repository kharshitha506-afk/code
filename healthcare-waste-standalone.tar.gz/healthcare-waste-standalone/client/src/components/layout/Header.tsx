import { useState } from "react";
import { Bell, Search, User, Check, Recycle, ShieldCheck } from "lucide-react";
import { useGetNotifications, useMarkNotificationRead } from "@/api/hooks";
import { cn, getPriorityColor } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

export function Header() {
  const [showNotifications, setShowNotifications] = useState(false);

  const { data: notifications = [] } = useGetNotifications();
  const { mutate: markAsRead } = useMarkNotificationRead();

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="h-20 glass-panel sticky top-0 z-20 flex items-center justify-between px-6 lg:px-10">
      {/* Search */}
      <div className="flex-1 max-w-xl hidden md:flex items-center relative">
        <Search className="w-5 h-5 absolute left-4 text-slate-400" />
        <input
          type="text"
          placeholder="Search items, categories, or IDs..."
          className="w-full bg-slate-100/60 border border-slate-200 rounded-full pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600/40 transition-all text-slate-800 placeholder:text-slate-400"
        />
      </div>
      <div className="flex-1 md:hidden" />

      {/* Right side */}
      <div className="flex items-center gap-4">
        {/* Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-600 transition-colors relative"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white" />
            )}
          </button>

          {showNotifications && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowNotifications(false)}
              />
              <div className="absolute right-0 top-12 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                  <h3 className="font-bold text-slate-900">Notifications</h3>
                  {unreadCount > 0 && (
                    <span className="text-xs bg-blue-600 text-white px-2 py-0.5 rounded-full font-medium">
                      {unreadCount} new
                    </span>
                  )}
                </div>
                <div className="max-h-[400px] overflow-y-auto p-2">
                  {notifications.length === 0 ? (
                    <div className="py-8 text-center text-slate-500 flex flex-col items-center gap-2">
                      <Bell className="w-8 h-8 text-slate-300" />
                      <p className="text-sm">No notifications right now.</p>
                    </div>
                  ) : (
                    notifications.map((notif) => (
                      <div
                        key={notif.id}
                        className={cn(
                          "p-3 rounded-xl mb-1 transition-colors relative group",
                          notif.isRead ? "opacity-60 hover:bg-slate-50" : "bg-blue-50/50 hover:bg-blue-50"
                        )}
                      >
                        <div className="flex gap-3 items-start">
                          <div className={cn("p-2 rounded-full mt-0.5 flex-shrink-0", getPriorityColor(notif.priority))}>
                            {notif.type === "recycling_due" ? (
                              <Recycle className="w-4 h-4" />
                            ) : notif.type === "compliance_alert" ? (
                              <ShieldCheck className="w-4 h-4" />
                            ) : (
                              <Bell className="w-4 h-4" />
                            )}
                          </div>
                          <div className="flex-1 pr-6 min-w-0">
                            <h4 className="text-sm font-semibold text-slate-900">{notif.title}</h4>
                            <p className="text-xs text-slate-600 mt-0.5 leading-snug">{notif.message}</p>
                            <span className="text-[10px] text-slate-400 mt-1.5 block font-medium">
                              {formatDistanceToNow(new Date(notif.timestamp), { addSuffix: true })}
                            </span>
                          </div>
                          {!notif.isRead && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                markAsRead({ id: notif.id });
                              }}
                              className="absolute right-3 top-3 p-1.5 bg-white shadow-sm rounded-full text-slate-400 hover:text-blue-600 transition-all opacity-0 group-hover:opacity-100"
                              title="Mark as read"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Divider + user */}
        <div className="h-8 w-px bg-slate-200" />
        <button className="flex items-center gap-3 p-1.5 pr-3 rounded-full hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white">
            <User className="w-5 h-5" />
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-sm font-semibold text-slate-900 leading-tight">Dr. Sarah Chen</p>
            <p className="text-xs text-slate-500 font-medium">Head of Operations</p>
          </div>
        </button>
      </div>
    </header>
  );
}
