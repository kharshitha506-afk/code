import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat("en-US").format(num);
}

export function getStatusColor(status: string): string {
  switch (status.toLowerCase()) {
    case "pending":  return "bg-amber-100 text-amber-800 border-amber-200";
    case "disposed": return "bg-blue-100 text-blue-800 border-blue-200";
    case "recycled": return "bg-emerald-100 text-emerald-800 border-emerald-200";
    default:         return "bg-slate-100 text-slate-800 border-slate-200";
  }
}

export function getPriorityColor(priority: string): string {
  switch (priority.toLowerCase()) {
    case "critical":
    case "high":   return "text-red-500 bg-red-50";
    case "medium": return "text-amber-500 bg-amber-50";
    default:       return "text-blue-500 bg-blue-50";
  }
}
