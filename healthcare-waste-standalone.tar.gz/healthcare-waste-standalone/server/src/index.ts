import "dotenv/config";
import app from "./app.js";

const port = parseInt(process.env.PORT || "5000", 10);

app.listen(port, () => {
  console.log(`✅ Healthcare Waste API Server running on http://localhost:${port}`);
  console.log(`   API available at http://localhost:${port}/api`);
});
