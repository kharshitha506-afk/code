import { Router } from "express";
import { eq, desc } from "drizzle-orm";
import { db, notificationsTable, wasteItemsTable } from "../db.js";

const router = Router();

// GET /api/notifications
router.get("/notifications", async (_req, res) => {
  const now = new Date();
  const in48hours = new Date();
  in48hours.setDate(in48hours.getDate() + 2);

  // Auto-create recycling-due notifications for upcoming pending items
  const pending = await db
    .select()
    .from(wasteItemsTable)
    .where(eq(wasteItemsTable.status, "pending"));

  for (const item of pending) {
    if (item.recyclingDate <= in48hours) {
      const existing = await db
        .select()
        .from(notificationsTable)
        .where(eq(notificationsTable.wasteItemId, item.id));

      const alreadyNotified = existing.some(
        (n) => n.type === "recycling_due" && !n.isRead
      );

      if (!alreadyNotified) {
        const hoursLeft = Math.round(
          (item.recyclingDate.getTime() - now.getTime()) / (1000 * 60 * 60)
        );
        await db.insert(notificationsTable).values({
          type: "recycling_due",
          title: hoursLeft <= 0 ? "OVERDUE: Recycling Required" : "Recycling Due Soon",
          message: `${item.type} waste item #${item.id} at ${item.location} ${hoursLeft <= 0 ? "is overdue for recycling" : `is due in ${Math.max(0, hoursLeft)} hours`}.`,
          wasteItemId: item.id,
          priority: hoursLeft <= 0 ? "critical" : hoursLeft <= 12 ? "high" : "medium",
        });
      }
    }
  }

  const notifications = await db
    .select()
    .from(notificationsTable)
    .orderBy(desc(notificationsTable.timestamp))
    .limit(50);

  res.json(notifications);
});

// POST /api/notifications/:id/read
router.post("/notifications/:id/read", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

  const [notif] = await db
    .update(notificationsTable)
    .set({ isRead: true })
    .where(eq(notificationsTable.id, id))
    .returning();

  if (!notif) return res.status(404).json({ error: "Notification not found" });
  res.json(notif);
});

export default router;
