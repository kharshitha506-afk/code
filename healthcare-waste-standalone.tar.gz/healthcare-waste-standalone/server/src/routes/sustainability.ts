import { Router } from "express";
import { db, wasteItemsTable } from "../db.js";

const router = Router();

router.get("/sustainability", async (_req, res) => {
  const all = await db.select().from(wasteItemsTable);

  const totalProcessed = all.length;
  const totalRecycled  = all.filter((i) => i.status === "recycled").length;
  const totalDisposed  = all.filter((i) => i.status === "disposed").length;
  const totalPending   = all.filter((i) => i.status === "pending").length;
  const recyclingRate  = totalProcessed > 0 ? (totalRecycled / totalProcessed) * 100 : 0;
  const co2Saved       = totalRecycled * 2;    // 2 kg CO₂ per recycled item
  const plasticRecycled = totalRecycled * 0.5; // 0.5 kg plastic per recycled item

  const wasteTypes = [
    "sharps", "infectious", "pharmaceutical", "chemical",
    "radioactive", "general", "pathological",
  ] as const;

  const wasteByType = wasteTypes.map((type) => {
    const items = all.filter((i) => i.type === type);
    return {
      type,
      count:    items.length,
      recycled: items.filter((i) => i.status === "recycled").length,
    };
  });

  // Last 8 weeks
  const weeklyTrend: { week: string; total: number; recycled: number }[] = [];
  for (let i = 7; i >= 0; i--) {
    const start = new Date();
    start.setDate(start.getDate() - i * 7 - 6);
    start.setHours(0, 0, 0, 0);

    const end = new Date();
    end.setDate(end.getDate() - i * 7);
    end.setHours(23, 59, 59, 999);

    const wItems = all.filter(
      (item) => item.timestamp >= start && item.timestamp <= end
    );

    weeklyTrend.push({
      week:     `W${8 - i}`,
      total:    wItems.length,
      recycled: wItems.filter((i) => i.status === "recycled").length,
    });
  }

  res.json({
    totalProcessed,
    totalRecycled,
    totalDisposed,
    totalPending,
    recyclingRate:  Math.round(recyclingRate * 10) / 10,
    co2Saved:       Math.round(co2Saved * 10) / 10,
    plasticRecycled: Math.round(plasticRecycled * 10) / 10,
    wasteByType,
    weeklyTrend,
  });
});

export default router;
