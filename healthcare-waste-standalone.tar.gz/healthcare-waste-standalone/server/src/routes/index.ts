import { Router } from "express";
import wasteRouter from "./waste.js";
import sustainabilityRouter from "./sustainability.js";
import complianceRouter from "./compliance.js";
import notificationsRouter from "./notifications.js";

const router = Router();

router.get("/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

router.use(wasteRouter);
router.use(sustainabilityRouter);
router.use(complianceRouter);
router.use(notificationsRouter);

export default router;
