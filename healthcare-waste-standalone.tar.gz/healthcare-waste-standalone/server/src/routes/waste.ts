import { Router } from "express";
import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import {
  db,
  wasteItemsTable,
  complianceLogsTable,
  notificationsTable,
} from "../db.js";

const router = Router();

const WASTE_TYPES = [
  "sharps",
  "infectious",
  "pharmaceutical",
  "chemical",
  "radioactive",
  "general",
  "pathological",
] as const;

function mockAiClassify(type: string): { classification: string; confidence: number } {
  const classMap: Record<string, { classification: string; confidence: number }> = {
    sharps:        { classification: "High-Risk Sharps Waste - Category B",               confidence: 0.97 },
    infectious:    { classification: "Infectious Biological Waste - WHO Class A",           confidence: 0.94 },
    pharmaceutical:{ classification: "Pharmaceutical Hazardous Waste - P-Listed",          confidence: 0.91 },
    chemical:      { classification: "Chemical Hazardous Waste - RCRA Regulated",          confidence: 0.89 },
    radioactive:   { classification: "Radioactive Medical Waste - Low Level",              confidence: 0.96 },
    general:       { classification: "Non-Hazardous General Medical Waste",                confidence: 0.98 },
    pathological:  { classification: "Pathological/Anatomical Waste - Incineration Required", confidence: 0.95 },
  };
  return classMap[type] ?? { classification: "Unclassified Waste", confidence: 0.5 };
}

async function addComplianceLog(
  action: "upload" | "disposal" | "recycling",
  wasteItemId: number,
  wasteType: string,
  description: string,
  notes?: string
) {
  await db.insert(complianceLogsTable).values({
    action,
    wasteItemId,
    wasteType,
    description,
    performedBy: "System Administrator",
    isCompliant: true,
    notes: notes ?? null,
  });
}

// GET /api/waste
router.get("/waste", async (req, res) => {
  const { status, type } = req.query;
  let items = await db
    .select()
    .from(wasteItemsTable)
    .orderBy(desc(wasteItemsTable.timestamp));

  if (status) items = items.filter((i) => i.status === status);
  if (type)   items = items.filter((i) => i.type === type);

  res.json(items);
});

// POST /api/waste
router.post("/waste", async (req, res) => {
  const schema = z.object({
    type:        z.enum(WASTE_TYPES),
    description: z.string().min(1),
    location:    z.string().min(1),
    quantity:    z.number().positive(),
    unit:        z.string().min(1),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request body", details: parsed.error.errors });
  }

  const { type, description, location, quantity, unit } = parsed.data;
  const ai = mockAiClassify(type);

  const recyclingDate = new Date();
  recyclingDate.setDate(recyclingDate.getDate() + 2);

  const [item] = await db
    .insert(wasteItemsTable)
    .values({ type, status: "pending", description, location, quantity, unit, aiClassification: ai.classification, aiConfidence: ai.confidence, recyclingDate })
    .returning();

  await addComplianceLog(
    "upload",
    item.id,
    type,
    `New ${type} waste item uploaded: ${description}`,
    `AI Classification: ${ai.classification} (${Math.round(ai.confidence * 100)}% confidence)`
  );

  await db.insert(notificationsTable).values({
    type: "pending_waste",
    title: "New Waste Item Added",
    message: `${type.charAt(0).toUpperCase() + type.slice(1)} waste uploaded at ${location}. Scheduled for recycling on ${recyclingDate.toLocaleDateString()}.`,
    priority: type === "radioactive" || type === "infectious" ? "high" : "medium",
    wasteItemId: item.id,
  });

  res.status(201).json(item);
});

// GET /api/waste/recycling/upcoming
router.get("/waste/recycling/upcoming", async (_req, res) => {
  const in48hours = new Date();
  in48hours.setDate(in48hours.getDate() + 2);

  const items = await db
    .select()
    .from(wasteItemsTable)
    .orderBy(wasteItemsTable.recyclingDate);

  const upcoming = items.filter(
    (i) => i.status === "pending" && i.recyclingDate <= in48hours
  );

  res.json(upcoming);
});

// GET /api/waste/:id
router.get("/waste/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

  const [item] = await db
    .select()
    .from(wasteItemsTable)
    .where(eq(wasteItemsTable.id, id));

  if (!item) return res.status(404).json({ error: "Waste item not found" });
  res.json(item);
});

// PATCH /api/waste/:id
router.patch("/waste/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

  const schema = z.object({
    status:      z.enum(["pending", "disposed", "recycled"]).optional(),
    description: z.string().optional(),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid body" });

  const [item] = await db
    .update(wasteItemsTable)
    .set(parsed.data)
    .where(eq(wasteItemsTable.id, id))
    .returning();

  if (!item) return res.status(404).json({ error: "Waste item not found" });
  res.json(item);
});

// POST /api/waste/:id/recycle
router.post("/waste/:id/recycle", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

  const [item] = await db
    .update(wasteItemsTable)
    .set({ status: "recycled", isRecycled: true, recycledAt: new Date() })
    .where(eq(wasteItemsTable.id, id))
    .returning();

  if (!item) return res.status(404).json({ error: "Waste item not found" });

  await addComplianceLog(
    "recycling",
    item.id,
    item.type,
    `Waste item #${item.id} (${item.type}) marked as recycled`,
    `Recycled on ${new Date().toISOString()}`
  );

  res.json(item);
});

// POST /api/waste/:id/dispose
router.post("/waste/:id/dispose", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });

  const [item] = await db
    .update(wasteItemsTable)
    .set({ status: "disposed", disposedAt: new Date() })
    .where(eq(wasteItemsTable.id, id))
    .returning();

  if (!item) return res.status(404).json({ error: "Waste item not found" });

  await addComplianceLog(
    "disposal",
    item.id,
    item.type,
    `Waste item #${item.id} (${item.type}) disposed`,
    `Disposed on ${new Date().toISOString()}`
  );

  res.json(item);
});

export default router;
