import { Router } from "express";
import { desc } from "drizzle-orm";
import { db, complianceLogsTable } from "../db.js";

const router = Router();

// GET /api/compliance/logs
router.get("/compliance/logs", async (req, res) => {
  const { action, limit } = req.query;
  const maxRows = parseInt(String(limit ?? "200")) || 200;

  let logs = await db
    .select()
    .from(complianceLogsTable)
    .orderBy(desc(complianceLogsTable.timestamp))
    .limit(maxRows);

  if (action) {
    logs = logs.filter((l) => l.action === action);
  }

  res.json(logs);
});

// GET /api/compliance/export  — CSV download
router.get("/compliance/export", async (_req, res) => {
  const logs = await db
    .select()
    .from(complianceLogsTable)
    .orderBy(desc(complianceLogsTable.timestamp));

  const headers = ["ID", "Action", "Waste Item ID", "Waste Type", "Description", "Performed By", "Timestamp", "Compliant", "Notes"];
  const rows = logs.map((l) => [
    l.id,
    l.action,
    l.wasteItemId,
    l.wasteType,
    `"${l.description.replace(/"/g, '""')}"`,
    `"${l.performedBy.replace(/"/g, '""')}"`,
    l.timestamp.toISOString(),
    l.isCompliant ? "Yes" : "No",
    `"${(l.notes ?? "").replace(/"/g, '""')}"`,
  ]);

  const csv = [headers.join(","), ...rows.map((r) => r.join(","))].join("\n");

  res.setHeader("Content-Type", "text/csv");
  res.setHeader(
    "Content-Disposition",
    `attachment; filename="compliance-report-${new Date().toISOString().split("T")[0]}.csv"`
  );
  res.send(csv);
});

export default router;
