import "dotenv/config";
import { db, wasteItemsTable, complianceLogsTable, notificationsTable } from "./db.js";

const WASTE_TYPES = ["sharps", "infectious", "pharmaceutical", "chemical", "radioactive", "general", "pathological"] as const;

const LOCATIONS = [
  "Ward A - Floor 2", "ICU Unit", "Surgical Suite 3", "Oncology Department",
  "Emergency Room", "Laboratory Wing B", "Radiology Department",
  "Pharmacy Storage", "Pediatric Ward", "Operating Theater 1",
];

const AI_CLASSIFICATIONS: Record<string, { classification: string; confidence: number }> = {
  sharps:        { classification: "High-Risk Sharps Waste - Category B",               confidence: 0.97 },
  infectious:    { classification: "Infectious Biological Waste - WHO Class A",           confidence: 0.94 },
  pharmaceutical:{ classification: "Pharmaceutical Hazardous Waste - P-Listed",          confidence: 0.91 },
  chemical:      { classification: "Chemical Hazardous Waste - RCRA Regulated",          confidence: 0.89 },
  radioactive:   { classification: "Radioactive Medical Waste - Low Level",              confidence: 0.96 },
  general:       { classification: "Non-Hazardous General Medical Waste",                confidence: 0.98 },
  pathological:  { classification: "Pathological/Anatomical Waste - Incineration Required", confidence: 0.95 },
};

const DESCRIPTIONS: Record<string, string[]> = {
  sharps:        ["Used syringes from insulin injections", "Surgical needles and sutures", "Lancets from blood glucose testing", "IV catheter needles"],
  infectious:    ["Contaminated dressings from wound care", "Soiled gloves and PPE from isolation ward", "Blood-soaked gauze from surgery", "Contaminated lab samples"],
  pharmaceutical:["Expired antibiotics - amoxicillin", "Unused chemotherapy drugs - cisplatin", "Expired insulin vials", "Cytotoxic drug residues"],
  chemical:      ["Formalin fixative solution", "Mercury-containing thermometers", "X-ray developer chemicals", "Disinfectant concentrate waste"],
  radioactive:   ["Technetium-99m generator waste", "I-131 therapy residuals", "Radiopharmaceutical packaging", "Contaminated absorbent pads"],
  general:       ["Office waste from admin section", "Non-contaminated packaging materials", "Paper and cardboard waste", "Clean packaging from supplies"],
  pathological:  ["Tissue samples from biopsies", "Placental waste from maternity ward", "Surgical excision specimens", "Anatomical specimens"],
};

const QUANTITIES: Record<string, { qty: number; unit: string }[]> = {
  sharps:        [{ qty: 15, unit: "units" }, { qty: 50, unit: "units" }, { qty: 3, unit: "kg" }],
  infectious:    [{ qty: 2.5, unit: "kg" }, { qty: 8, unit: "liters" }, { qty: 12, unit: "bags" }],
  pharmaceutical:[{ qty: 1.2, unit: "kg" }, { qty: 500, unit: "ml" }, { qty: 24, unit: "vials" }],
  chemical:      [{ qty: 5, unit: "liters" }, { qty: 2.8, unit: "kg" }, { qty: 10, unit: "liters" }],
  radioactive:   [{ qty: 0.5, unit: "kg" }, { qty: 3, unit: "units" }, { qty: 1.5, unit: "kg" }],
  general:       [{ qty: 25, unit: "kg" }, { qty: 15, unit: "bags" }, { qty: 40, unit: "kg" }],
  pathological:  [{ qty: 3, unit: "containers" }, { qty: 1.5, unit: "kg" }, { qty: 5, unit: "specimens" }],
};

const OPERATORS = [
  "Dr. Sarah Mitchell", "Nurse John Carter", "Lab Tech Emma Wilson",
  "Pharmacist David Brown", "Radiologist Dr. Lee",
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomDate(daysAgo: number, minDaysAgo = 0): Date {
  const d = new Date();
  const offset = Math.floor(Math.random() * (daysAgo - minDaysAgo + 1)) + minDaysAgo;
  d.setDate(d.getDate() - offset);
  d.setHours(Math.floor(Math.random() * 12) + 7, Math.floor(Math.random() * 60), 0, 0);
  return d;
}

async function seed() {
  console.log("🌱 Clearing existing data...");
  await db.delete(notificationsTable);
  await db.delete(complianceLogsTable);
  await db.delete(wasteItemsTable);

  console.log("📦 Seeding 60 waste items...");
  const wasteRows: (typeof wasteItemsTable.$inferInsert)[] = [];

  for (let i = 0; i < 60; i++) {
    const type     = pick(WASTE_TYPES);
    const location = pick(LOCATIONS);
    const description = pick(DESCRIPTIONS[type]);
    const qtyOpt  = pick(QUANTITIES[type]);
    const ai      = AI_CLASSIFICATIONS[type];
    const timestamp = randomDate(30, 3);
    const recyclingDate = new Date(timestamp);
    recyclingDate.setDate(recyclingDate.getDate() + 2);

    const now = new Date();
    const daysOld = (now.getTime() - timestamp.getTime()) / (1000 * 60 * 60 * 24);

    let status: "pending" | "disposed" | "recycled" = "pending";
    if (daysOld > 4)      status = Math.random() > 0.3 ? "recycled" : "disposed";
    else if (daysOld > 2) status = Math.random() > 0.5 ? "recycled" : "pending";

    wasteRows.push({
      type, status, description, location,
      quantity: qtyOpt.qty, unit: qtyOpt.unit,
      aiClassification: ai.classification, aiConfidence: ai.confidence,
      timestamp, recyclingDate,
      isRecycled: status === "recycled",
      disposedAt: status === "disposed" ? new Date(recyclingDate.getTime() + Math.random() * 86400000) : null,
      recycledAt: status === "recycled" ? new Date(recyclingDate.getTime() + Math.random() * 43200000) : null,
    });
  }

  const insertedItems = await db.insert(wasteItemsTable).values(wasteRows).returning();
  console.log(`✅ Inserted ${insertedItems.length} waste items`);

  const complianceRows: (typeof complianceLogsTable.$inferInsert)[] = [];
  for (const item of insertedItems) {
    complianceRows.push({
      action: "upload", wasteItemId: item.id, wasteType: item.type,
      description: `Waste item uploaded: ${item.description}`,
      performedBy: pick(OPERATORS), timestamp: item.timestamp, isCompliant: true,
      notes: `AI: ${item.aiClassification} (${Math.round(item.aiConfidence * 100)}%)`,
    });
    if (item.status === "recycled") {
      complianceRows.push({
        action: "recycling", wasteItemId: item.id, wasteType: item.type,
        description: `Item #${item.id} recycled: ${item.description}`,
        performedBy: pick(["Waste Officer Tom Reed", "Environmental Services"]),
        timestamp: item.recycledAt ?? item.recyclingDate, isCompliant: true,
        notes: "Recycling completed per protocol HWM-2024",
      });
    }
    if (item.status === "disposed") {
      complianceRows.push({
        action: "disposal", wasteItemId: item.id, wasteType: item.type,
        description: `Item #${item.id} disposed: ${item.description}`,
        performedBy: pick(["Waste Officer Tom Reed", "Disposal Contractor - BioClean Ltd"]),
        timestamp: item.disposedAt ?? item.recyclingDate, isCompliant: true,
        notes: "Disposal via incineration - regulatory compliance",
      });
    }
  }

  await db.insert(complianceLogsTable).values(complianceRows);
  console.log(`✅ Inserted ${complianceRows.length} compliance logs`);

  await db.insert(notificationsTable).values([
    {
      type: "system", title: "System Initialized",
      message: "AI Healthcare Waste Management System is now active and monitoring.",
      priority: "low", wasteItemId: null,
    },
    {
      type: "compliance_alert", title: "Weekly Compliance Report Ready",
      message: "Your weekly compliance report is ready. Current compliance rate: 100%.",
      priority: "medium", wasteItemId: null,
    },
  ]);

  console.log("🎉 Database seeded successfully!");
  console.log("\nSummary:");
  console.log(`  - ${insertedItems.length} waste items`);
  console.log(`  - ${complianceRows.length} compliance logs`);
  console.log(`  - 2 notifications`);
  process.exit(0);
}

seed().catch((err) => {
  console.error("❌ Seed failed:", err);
  process.exit(1);
});
