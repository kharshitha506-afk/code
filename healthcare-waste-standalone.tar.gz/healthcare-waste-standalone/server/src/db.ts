import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import {
  pgTable,
  serial,
  text,
  timestamp,
  boolean,
  real,
  integer,
  pgEnum,
} from "drizzle-orm/pg-core";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is required.\n" +
    "Copy .env.example to .env and set your PostgreSQL connection string."
  );
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool);

// ─── Enums ────────────────────────────────────────────────────────────────────

export const wasteTypeEnum = pgEnum("waste_type", [
  "sharps",
  "infectious",
  "pharmaceutical",
  "chemical",
  "radioactive",
  "general",
  "pathological",
]);

export const wasteStatusEnum = pgEnum("waste_status", [
  "pending",
  "disposed",
  "recycled",
]);

export const complianceActionEnum = pgEnum("compliance_action", [
  "upload",
  "disposal",
  "recycling",
]);

export const notificationTypeEnum = pgEnum("notification_type", [
  "recycling_due",
  "pending_waste",
  "compliance_alert",
  "system",
]);

export const notificationPriorityEnum = pgEnum("notification_priority", [
  "low",
  "medium",
  "high",
  "critical",
]);

// ─── Tables ───────────────────────────────────────────────────────────────────

export const wasteItemsTable = pgTable("waste_items", {
  id: serial("id").primaryKey(),
  type: wasteTypeEnum("type").notNull(),
  status: wasteStatusEnum("status").notNull().default("pending"),
  description: text("description").notNull(),
  location: text("location").notNull(),
  quantity: real("quantity").notNull(),
  unit: text("unit").notNull(),
  aiClassification: text("ai_classification").notNull(),
  aiConfidence: real("ai_confidence").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).defaultNow().notNull(),
  recyclingDate: timestamp("recycling_date", { withTimezone: true }).notNull(),
  isRecycled: boolean("is_recycled").default(false).notNull(),
  disposedAt: timestamp("disposed_at", { withTimezone: true }),
  recycledAt: timestamp("recycled_at", { withTimezone: true }),
});

export const complianceLogsTable = pgTable("compliance_logs", {
  id: serial("id").primaryKey(),
  action: complianceActionEnum("action").notNull(),
  wasteItemId: integer("waste_item_id")
    .notNull()
    .references(() => wasteItemsTable.id),
  wasteType: text("waste_type").notNull(),
  description: text("description").notNull(),
  performedBy: text("performed_by").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).defaultNow().notNull(),
  isCompliant: boolean("is_compliant").default(true).notNull(),
  notes: text("notes"),
});

export const notificationsTable = pgTable("notifications", {
  id: serial("id").primaryKey(),
  type: notificationTypeEnum("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  wasteItemId: integer("waste_item_id").references(() => wasteItemsTable.id),
  isRead: boolean("is_read").default(false).notNull(),
  priority: notificationPriorityEnum("priority").notNull().default("medium"),
  timestamp: timestamp("timestamp", { withTimezone: true }).defaultNow().notNull(),
});

// ─── Types ────────────────────────────────────────────────────────────────────

export type WasteItem = typeof wasteItemsTable.$inferSelect;
export type ComplianceLog = typeof complianceLogsTable.$inferSelect;
export type Notification = typeof notificationsTable.$inferSelect;
