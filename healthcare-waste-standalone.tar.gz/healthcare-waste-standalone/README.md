# AI-Powered Healthcare Waste Management System

A full-stack SaaS dashboard for hospitals to manage biomedical waste with AI classification.

## Features

- **Waste Upload** — Log waste with AI-powered automatic classification & confidence scoring
- **Dashboard** — Real-time stats: total processed, recycled, disposed, pending
- **Recycling Scheduler** — Auto-schedules recycling every 2 days, mark as recycled
- **Sustainability Metrics** — CO₂ saved, recycling rate %, plastic recycled, charts
- **History Panel** — Archive of all completed (disposed/recycled) waste items
- **Compliance Logs** — Full audit log with CSV export
- **Notifications** — Priority-coded alerts for recycling due, pending waste

## Tech Stack

- **Frontend**: React 18, Vite, Tailwind CSS v4, TanStack Query, Framer Motion, Recharts
- **Backend**: Node.js, Express 5, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Routing**: Wouter
- **Forms**: React Hook Form + Zod

## Prerequisites

- Node.js 18 or higher (`node -v` to check)
- PostgreSQL database (local install, [Neon](https://neon.tech), or [Supabase](https://supabase.com))
- npm (included with Node.js)

## Quick Start

### 1. Clone / Download the project

```bash
cd healthcare-waste-standalone
```

### 2. Install all dependencies

```bash
npm run install:all
```

### 3. Set up environment variables

```bash
cp .env.example .env
```

Open `.env` and fill in your `DATABASE_URL`. Example:
- **Local PostgreSQL**: `postgresql://postgres:yourpassword@localhost:5432/healthcare_waste`
- **Neon** (free cloud DB): Create a project at [neon.tech](https://neon.tech) and copy the connection string

### 4. Push database schema

```bash
npm run db:push
```

### 5. Seed sample data (optional but recommended)

```bash
npm run seed
```

This inserts 60 realistic waste items, 100+ compliance logs, and notifications.

### 6. Start the development server

```bash
npm run dev
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start both server and client in development mode |
| `npm run build` | Build the React frontend for production |
| `npm run start` | Run the backend server in production mode |
| `npm run db:push` | Push database schema to PostgreSQL |
| `npm run seed` | Seed the database with sample data |
| `npm run install:all` | Install dependencies for root, server, and client |

## Project Structure

```
healthcare-waste-standalone/
├── server/             # Express.js backend
│   ├── src/
│   │   ├── index.ts    # Server entry point
│   │   ├── app.ts      # Express app setup
│   │   ├── db.ts       # Database connection + Drizzle schema
│   │   ├── seed.ts     # Sample data seeder
│   │   └── routes/     # API route handlers
│   ├── drizzle.config.ts
│   └── package.json
└── client/             # React + Vite frontend
    ├── src/
    │   ├── api/        # Fetch-based API hooks
    │   ├── pages/      # Dashboard, Upload, Recycling, etc.
    │   ├── components/ # Layout and UI components
    │   └── types/      # TypeScript types
    └── package.json
```

## VS Code Setup (Recommended)

Install the **ESLint** and **Tailwind CSS IntelliSense** extensions for the best experience.

Open each folder (`server/` and `client/`) as workspace folders for proper TypeScript IntelliSense.
